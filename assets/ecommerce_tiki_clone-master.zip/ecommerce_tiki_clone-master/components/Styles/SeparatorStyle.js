import React from 'react';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  separator: {
    backgroundColor: '#555',
    height: 0.5,
    flex: 1,
  },
});
export default styles;
