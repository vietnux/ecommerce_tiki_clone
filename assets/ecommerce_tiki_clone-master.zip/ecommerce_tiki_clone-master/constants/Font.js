const cost = 25;
const costDiscount = 15;

export default {cost, costDiscount};
