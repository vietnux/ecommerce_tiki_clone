const iconSearch = 'ios-search';

export default {iconSearch};
