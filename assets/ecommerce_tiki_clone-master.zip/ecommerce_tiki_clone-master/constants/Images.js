const Login =
  'https://salt.tikicdn.com/cache/w584/ts/banner/9c/50/20/22d6f05240f7df1388ec2e003a520d0f.png';
const FlashSale =
  'https://salt.tikicdn.com/ts/banner/7c/aa/05/05f8119e8d13328a782a35ec01a7ea8d.png';

const sale =
  'https://salt.tikicdn.com/cache/w150/ts/banner/bf/45/b2/e9a8306c49607fb054a3c6651ee7b647.png';
const sale1 =
  'https://salt.tikicdn.com/cache/w206/ts/banner/c8/05/12/635ce7d94d1e9b837188d7426f84c290.png';
const sale2 =
  'https://salt.tikicdn.com/cache/w206/ts/banner/f1/dd/67/840f01845b71bdfeb524d8c582e6620e.png';
const sale3 =
  'https://salt.tikicdn.com/cache/w206/ts/banner/2b/c5/83/e4276c94c5ba58dc1b17f894f70a921f.png';
const sale4 =
  'https://salt.tikicdn.com/cache/w206/ts/banner/82/a6/d9/f93216a7d8eb59be896cf25971845d0b.png';

const hunt =
  'https://salt.tikicdn.com/cache/w1208/ts/brickv2og/9c/1f/22/8f0567dcb665132399adb9d4008d74bd.png';
const viewbuy1 =
  'https://salt.tikicdn.com/ts/categoryblock/fc/9c/6e/45be5f8980333f8db683369af2e367dc.png';

const viewbuy2 =
  'https://salt.tikicdn.com/ts/categoryblock/a6/6c/99/fc04c3f3cd159912be5c9203a56ec619.png';
const viewbuy3 =
  'https://salt.tikicdn.com/ts/categoryblock/72/10/cc/3bc95403a6d1ef3b1123400366802b53.png';
const viewbuy4 =
  'https://salt.tikicdn.com/ts/categoryblock/54/1a/7e/02dec76ccd7f6a04a0868afff8b2f414.png';
const viewbuy5 =
  'https://salt.tikicdn.com/ts/categoryblock/a3/30/d2/02e2b3ac19105d5c0daf7d579971b2f8.png';
const searchHot1 =
  'https://salt.tikicdn.com/cache/w295/ts/banner/50/4b/e4/5a0692d8322d9c1942775521b47c8cf0.png';
const searchHot2 =
  'https://salt.tikicdn.com/cache/w295/ts/banner/e1/07/58/8fc18b29e2538919c77bcac684562008.png';
const searchHot3 =
  'https://salt.tikicdn.com/cache/w295/ts/banner/c1/1e/45/43b24eacdb2cb52be676cff4a3581996.png';
const searchHot4 =
  'https://salt.tikicdn.com/cache/w295/ts/banner/7a/b5/74/afb0e35b7df84774a2fb05d7eaff9f9a.png';
const modalHome =
  'https://salt.tikicdn.com/cache/w150/ts/banner/94/59/9b/327747ca9a4d953092a799920246616c.png';
const emptyOrder = 'https://salt.tikicdn.com/desktop/img/mascot@2x.png';
const talkWithTiki =
  'https://salt.tikicdn.com/ts/upload/f1/a5/20/a9f1aeff49e9b6bec99246ed9e693517.png';
const notificationBanner =
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_8M0--ifTdoVG6WvwauXL2vPJMRkJIMe5rA&usqp=CAU';

const policyImg1 =
  'https://frontend.tikicdn.com/_desktop-next/static/img/icons/compensation.svg';
const policyImg2 =
  'https://frontend.tikicdn.com/_desktop-next/static/img/pdp_revamp_v2/guarantee.svg';
const policyImg3 =
  'https://frontend.tikicdn.com/_desktop-next/static/img/icons/refund.svg';
export default {
  Login,
  FlashSale,
  sale,
  sale1,
  sale2,
  sale3,
  sale4,
  hunt,
  viewbuy1,
  viewbuy2,
  viewbuy3,
  viewbuy4,
  viewbuy5,
  searchHot1,
  searchHot2,
  searchHot3,
  searchHot4,
  modalHome,
  emptyOrder,
  talkWithTiki,
  notificationBanner,
  policyImg1,
  policyImg2,
  policyImg3,
};
