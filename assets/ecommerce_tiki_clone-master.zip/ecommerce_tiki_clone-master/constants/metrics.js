export const iconMedium = 27;
export const iconLarge = 30;

export default {iconMedium, iconLarge};
