const textSearch = 'Bạn tìm gì hôm nay ?';
const placeHolderSearch = 'Sản phẩm thương hiệu và mọi thứ bạn cần';
const emptyProductText = 'Bạn chưa có sản phẩm nào trong giỏ hàng';

export default {textSearch, placeHolderSearch, emptyProductText};
