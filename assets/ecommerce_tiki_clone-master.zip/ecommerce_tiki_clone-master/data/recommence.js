export const recommenceData = [
  {
    title: 'Anise Aroma Art Bazar',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/e3/10/b0/83cce70414ccd0e06b61252cb1dfccc8.png',
    id: 1,
  },
  {
    title: 'Food inside a Bowl',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/eb/2e/2d/98fa3bedd9d7c1d900026a958c51f0c3.png',
    id: 2,
  },
  {
    title: 'Vegatable Salad',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/2e/32/ab/9b6e643667f5439197a061b6f21d546f.png',
    id: 3,
  },
];
