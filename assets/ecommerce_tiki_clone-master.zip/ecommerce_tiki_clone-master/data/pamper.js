export const pamperData = [
  {
    title: 'Mã giảm giá',
    url:
      'https://salt.tikicdn.com/ts/upload/73/50/e1/83afc85db37c472de60ebef6eceb41a7.png',
    id: 1,
  },
  {
    title: 'Nạp thẻ',
    url:
      'https://salt.tikicdn.com/ts/upload/07/05/6d/dd5e7d873aa1960102a9508703f79333.png',
    id: 2,
  },
  {
    title: 'Free Ship',
    url:
      'https://salt.tikicdn.com/ts/upload/c2/da/13/638cc2dc09b1be2e148c0571a107281a.png',
    id: 3,
  },
  {
    title: 'Hoàn tiền 15%',
    url:
      'https://salt.tikicdn.com/ts/upload/52/50/73/0788d5207ec8b82e05859dfe953a4327.png',
    id: 4,
  },
  {
    title: 'Dành cho hội viên',
    url:
      'https://salt.tikicdn.com/ts/upload/ce/ee/fe/a8a350727b38a1e20ce1610c5162fcb7.png',
    id: 5,
  },
  {
    title: 'Hẹn giao, lắp đặt',
    url:
      'https://salt.tikicdn.com/ts/upload/a9/58/39/872e4acbdb3576be53b57c05a386860b.png',
    id: 6,
  },
  {
    title: 'Coupon 50%',
    url:
      'https://salt.tikicdn.com/ts/upload/46/7e/06/64c9e7975b58b8953a74fe77dd4cb4b5.png',
    id: 7,
  },
  {
    title: 'Thực phẩm tươi sống',
    url:
      'https://salt.tikicdn.com/ts/upload/a0/0d/90/bab67b6da67117f40538fc54fb2dcb5e.png',
    id: 8,
  },
  {
    title: 'Ưu đãi đối tác',
    url:
      'https://salt.tikicdn.com/ts/upload/4a/b2/c5/b388ee0e511889c83fab1217608fe82f.png',
    id: 9,
  },
  {
    title: 'Bia & Rượu',
    url:
      'https://salt.tikicdn.com/ts/upload/e1/9b/88/2568788514db034ecc51dcc46fe4341e.png',
    id: 10,
  },
];
