export const hotdealData = [
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/02/99/a6/81f940761561045ea785ef83a60d59eb.jpg',
    price: '75.000 đ',
    discount: '-55%',
    buy: 'Đã bán 2',
    id: 1,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/0a/ed/6b/aaf2592e3a8e6937fe6d4b2d2429deae.png',
    price: '110.000 đ',
    discount: '-47%',
    buy: 'Đã bán 16',
    id: 2,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/e5/64/56/dd311cb7cff90abfcad8e7cdf2d79096.jpg',
    price: '1.000.000 đ',
    discount: '-41%',
    buy: 'Đã bán 92',
    id: 3,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/dd/1b/fc/97c9223d8a1df2e13d953dbf2ba1f982.jpg',
    price: '999.000 đ',
    discount: '-53%',
    buy: 'Đã bán 10',
    id: 4,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/0e/18/14/ec490ca6a466478f31dcbcf74e5672c7.jpg',
    price: '30.000 đ',
    discount: '-64%',
    buy: 'Đã bán 32',
    id: 5,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/12/c5/e0/77019bf76129b3802039888523120b13.jpg',
    price: '50.000 đ',
    discount: '-28%',
    buy: 'Đã bán 7',
    id: 6,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/aa/ad/0b/b5a3a4fe89b07a27f474a17bcb46bf41.jpg',
    price: '10.000 đ',
    discount: '-50%',
    buy: 'Đã bán 9',
    id: 7,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/33/7e/cb/9ce1449e783609b5e1673e90fe90a843.jpg',
    price: '50.000 đ',
    discount: '-57%',
    buy: 'Đã bán 93',
    id: 8,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/42/f6/0d/724486b438a5e973b76a0d57c5fe84f3.jpg',
    price: '95.000 đ',
    discount: '-70%',
    buy: 'Sắp hết',
    id: 9,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/280x280/ts/product/ef/c6/06/7473bd857cc412701c4a385c142376d1.jpg',
    price: '225.000 đ',
    discount: '-71%',
    buy: 'Đã bán 59',
    id: 10,
  },
];
