export const dummyData = [
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/1a/c0/e2/d0dfc2f6ee8e53428851c96ef345761f.png',

    id: 1,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/59/44/53/f2838b527e9ec8b0d6700976e69856ff.png',

    id: 2,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/d4/a3/8b/0e386541406821860f577251dd73663e.png',

    id: 3,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/af/da/06/d644472171a8fb80f4d1f8e315e625d9.png',

    id: 4,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/b4/56/8d/89835c6f666f862c6e77a08719b2aeb8.png',

    id: 5,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/53/ff/ed/8ad0e68b303fb664d0e60024d1f3a398.png',

    id: 6,
  },
  {
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/a2/e4/cb/97af1243c4b6e29949059183f783a9bc.jpg',

    id: 7,
  },
];
