export const dataTween = [
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/1c/f0/c3/74f25a8ae0a5f9a576e0fef5f3cbf3b3.png',
    id: 1,
  },
  {
    title: 'Miếng lót sơ sinh',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/6a/22/ce/523d94ffa578dff2e7954c369a59f428.jpg',
    id: 2,
  },
  {
    title: 'Tã quần',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/2a/b2/ea/70ee0777220d8c4401a463e7ecb33efb.png',
    id: 3,
  },
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/6f/3d/3b/db87475efb01ca4c8847dbc1ed0e3cfc.png',
    id: 4,
  },
  {
    title: 'Tã vải',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/a7/d6/c7/dfae31ebe08ec3cb2734927a8f663f10.png',
    id: 5,
  },
  {
    title: 'Khăn giấy ướt cho bé',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/80/95/44/f0880dde09f6e9035df55540da667a91.png',
    id: 6,
  },
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/80/95/44/f0880dde09f6e9035df55540da667a91.png',
    id: 75,
  },
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/80/95/44/f0880dde09f6e9035df55540da667a91.png',
    id: 4555,
  },
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/80/95/44/f0880dde09f6e9035df55540da667a91.png',
    id: 74556566,
  },
  {
    title: 'Tã dán',
    url:
      'https://salt.tikicdn.com/cache/w584/ts/banner/80/95/44/f0880dde09f6e9035df55540da667a91.png',
    id: 786565686,
  },
];
